class Message {
  final String text;
  final String time;
  final String senderNumber;
  Message({this.text, this.time, this.senderNumber});
}
