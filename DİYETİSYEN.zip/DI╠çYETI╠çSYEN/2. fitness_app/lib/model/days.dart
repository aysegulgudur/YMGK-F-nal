wclass Day {
  String dayName;
  String dayNumber;
  Day(this.dayName, this.dayNumber);
}

List<Day> days = [
  Day('SUN', '01'),
  Day('MON', '02'),
  Day('TUE', '03'),
  Day('WED', '04'),
  Day('THU', '05'),
  Day('FRI', '06'),
  Day('SAT', '07'),
];