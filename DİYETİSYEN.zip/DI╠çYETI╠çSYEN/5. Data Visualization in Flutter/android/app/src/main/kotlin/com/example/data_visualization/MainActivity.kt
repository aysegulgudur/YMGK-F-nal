package com.example.data_visualization

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
