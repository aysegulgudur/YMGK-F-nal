package com.example.top_10

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
